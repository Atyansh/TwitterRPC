#!/bin/bash

thrift --gen py ../thrift/Twitter.thrift
